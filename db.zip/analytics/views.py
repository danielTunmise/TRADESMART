from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import User
from django.http import HttpResponse, JsonResponse
from django.utils.timezone import make_aware
from datetime import datetime, timedelta
from reportlab.pdfgen import canvas
import asyncio
from django.conf import settings
from asgiref.sync import async_to_sync
import calendar
import ast 
import hashlib
from .models import Trade, UserProfile, TradeNote, TradingAccount, AccountBalance
from .forms import ProfileUpdateForm, TradeImportForm
from django.db.models import Sum
from django.utils import timezone
import uuid
import pandas as pd
from django.contrib import messages
from .cloud_connector import TradeSmartCloud
import io
import math
import re # Added for robust number extraction
from django.urls import reverse

# =========================================================
#  HELPER FUNCTIONS
# =========================================================

def extract_clean_symbol(obj):
    """
    Recursively digs through nested dictionaries to find a clean symbol string.
    """
    if not obj: return "Unknown"
    
    if isinstance(obj, str):
        try:
            if obj.strip().startswith('{'):
                obj = ast.literal_eval(obj)
            else:
                return obj 
        except:
            return obj

    if isinstance(obj, dict):
        if 'raw_symbol' in obj and obj['raw_symbol']:
            return extract_clean_symbol(obj['raw_symbol'])
        
        if 'symbol' in obj and obj['symbol']:
            val = obj['symbol']
            if isinstance(val, str) and not val.strip().startswith('{'):
                return val
            return extract_clean_symbol(val)
            
        if 'description' in obj: return obj['description']
        if 'name' in obj: return obj['name']

    return str(obj)

def generate_trade_id(order):
    """
    Generates a deterministic unique ID based on trade properties.
    Crucial for when API returns None for IDs.
    """
    if order.get('id'):
        return str(order.get('id'))
    
    # Create unique signature: Time + Symbol + Action + Units + Price
    raw_sig = f"{order.get('time_executed')}-{order.get('symbol')}-{order.get('action')}-{order.get('filled_quantity')}-{order.get('execution_price')}"
    return hashlib.md5(raw_sig.encode()).hexdigest()

def generate_linking_key(symbol, quantity):
    """
    Creates a unique key based on Symbol + Quantity.
    This acts as the bridge between Live positions and Closed trades.
    """
    try:
        # Standardize quantity to 4 decimal places to ensure match (e.g. 1 vs 1.0000)
        qty_clean = f"{float(quantity):.4f}"
    except:
        qty_clean = str(quantity)
    return f"{symbol}_{qty_clean}"

def get_active_account(request):
    user_accounts = TradingAccount.objects.filter(user=request.user)
    if not user_accounts.exists():
        return None, user_accounts

    selected_id = request.GET.get('account_id')
    if selected_id:
        request.session['active_account_id'] = selected_id
        current_account = user_accounts.filter(id=selected_id).first()
    else:
        session_id = request.session.get('active_account_id')
        if session_id:
            current_account = user_accounts.filter(id=session_id).first()
        else:
            current_account = user_accounts.first()
            if current_account:
                request.session['active_account_id'] = current_account.id
    
    if not current_account:
        current_account = user_accounts.first()

    return current_account, user_accounts

# =========================================================
#  VIEWS
# =========================================================

# --- 1. AUTHENTICATION ---
def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        password_confirm = request.POST.get('password_confirm')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        risk = request.POST.get('risk_appetite', 'moderate').lower()

        if password != password_confirm:
            return render(request, 'register.html', {'error': 'Passwords do not match'})

        if not User.objects.filter(username=username).exists():
            user = User.objects.create_user(username=username, password=password, first_name=first_name, last_name=last_name)
            UserProfile.objects.get_or_create(user=user, defaults={'risk_appetite': risk})
            return redirect('login')
        else:
            return render(request, 'register.html', {'error': 'Username already taken'})
    return render(request, 'register.html')

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

# --- 2. BROKER SYNC ---
@login_required
def sync_trading_data(request):
    return redirect('dashboard')

# --- 3. DASHBOARD ---
@login_required
def dashboard(request):
    current_account, user_accounts = get_active_account(request)

    # Initialize Containers
    stats = {'win_rate': 0, 'profit_factor': 0.0, 'day_win_rate': 0}
    equity_curve = [{'date': 'Start', 'value': 0.0}]
    drawdown_curve = [{'date': 'Start', 'value': 0.0}]
    monthly_days = []
    daily_map = {}
    positions = []
    
    # State flags
    is_connected = False
    live_balance = 0.00
    buying_power = 0.00
    
    # This list will hold standardized trade objects from EITHER source
    all_processed_trades = []

    if current_account:
        # =========================================================
        # PATH A: API ACCOUNT (Fetch from Cloud)
        # =========================================================
        if current_account.snaptrade_user_id:
            try:
                client = TradeSmartCloud()
                ST_UID = current_account.snaptrade_user_id
                ST_SECRET = current_account.user_secret
                
                cloud_accounts = client.get_accounts(ST_UID, ST_SECRET)
                if cloud_accounts:
                    is_connected = True
                    acc_id = cloud_accounts[0]['id']
                    
                    # 1. Fetch Balance
                    balance_data = client.api.account_information.get_user_account_balance(ST_UID, ST_SECRET, acc_id)
                    if balance_data.body:
                        live_balance = float(balance_data.body[0].get('cash', 0) or 0.0)
                        buying_power = balance_data.body[0].get('buying_power', 0)

                    # 2. Fetch Orders
                    orders_res = client.api.account_information.get_user_account_orders(ST_UID, ST_SECRET, acc_id)
                    all_orders = orders_res.body if isinstance(orders_res.body, list) else []
                    
                    # FIFO Processing Logic
                    chron_orders = sorted(all_orders, key=lambda x: x.get('time_executed') or x.get('time_placed') or '0000-00-00', reverse=False)
                    inventory = {} 

                    for order in chron_orders:
                        # Date Parsing
                        raw_date = (order.get('time_executed') or order.get('time_placed') or order.get('time_updated') or order.get('execution_time'))
                        trade_dt = timezone.now()
                        if raw_date:
                            try:
                                if str(raw_date).isdigit(): 
                                    trade_dt = datetime.fromtimestamp(int(raw_date) / 1000.0)
                                    trade_dt = make_aware(trade_dt)
                                else: 
                                    trade_dt = datetime.fromisoformat(str(raw_date).replace('Z', '+00:00'))
                            except: pass
                        
                        d_str = trade_dt.strftime("%Y-%m-%d")

                        # Data Extraction
                        sym_obj = order.get('universal_symbol') or order.get('symbol')
                        symbol = extract_clean_symbol(sym_obj)
                        action = order.get('action', '').upper()
                        units = float(order.get('filled_quantity') or order.get('total_quantity') or 0.0)
                        price = float(order.get('execution_price') or order.get('price') or 0.0)
                        
                        trade_pnl = 0.0; trade_closed = False; closing_price = price; opening_price = 0.0

                        # FIFO Calculation
                        if symbol not in inventory: inventory[symbol] = {'qty': 0.0, 'avg_price': 0.0}
                        current_qty = inventory[symbol]['qty']; avg_entry = inventory[symbol]['avg_price']

                        if action == 'BUY':
                            if current_qty < 0: # Closing Short
                                opening_price = avg_entry; cover_qty = min(abs(current_qty), units)
                                trade_pnl = (avg_entry - price) * cover_qty; trade_closed = True
                                inventory[symbol]['qty'] += cover_qty
                                if inventory[symbol]['qty'] == 0: inventory[symbol]['avg_price'] = 0.0
                                if units - cover_qty > 0: inventory[symbol]['qty'] += (units - cover_qty); inventory[symbol]['avg_price'] = price 
                            else: # Opening Long
                                total_val = (current_qty * avg_entry) + (units * price); new_total_qty = current_qty + units
                                if new_total_qty > 0: inventory[symbol]['avg_price'] = total_val / new_total_qty
                                inventory[symbol]['qty'] = new_total_qty
                        elif action == 'SELL':
                            if current_qty > 0: # Closing Long
                                opening_price = avg_entry; close_qty = min(current_qty, units)
                                trade_pnl = (price - avg_entry) * close_qty; trade_closed = True
                                inventory[symbol]['qty'] -= close_qty
                                if inventory[symbol]['qty'] == 0: inventory[symbol]['avg_price'] = 0.0
                                if units - close_qty > 0: inventory[symbol]['qty'] -= (units - close_qty); inventory[symbol]['avg_price'] = price 
                            else: # Opening Short
                                total_val = (abs(current_qty) * avg_entry) + (units * price); new_total_abs_qty = abs(current_qty) + units
                                if new_total_abs_qty > 0: inventory[symbol]['avg_price'] = total_val / new_total_abs_qty
                                inventory[symbol]['qty'] -= units

                        if trade_closed:
                            direction = 'LONG' if action == 'SELL' else 'SHORT'
                            tid = generate_trade_id(order)
                            
                            all_processed_trades.append({
                                'trade_id': tid,
                                'symbol': symbol,
                                'direction': direction,
                                'lot_size': units,
                                'profit': round(trade_pnl, 2),
                                'open_price': round(opening_price, 2),
                                'close_price': round(closing_price, 2),
                                'sort_date': trade_dt,
                                'date_str': d_str,
                                'source': 'API'
                            })

            except Exception as e: 
                print(f"Dashboard API Error: {e}")

        # =========================================================
        # PATH B: MANUAL ACCOUNT (Fetch from Database)
        # =========================================================
        else:
            # Manual accounts are "connected" to the DB
            is_connected = True 
            
            try:
                # 1. FETCH BALANCE FROM DB
                balance_obj = AccountBalance.objects.filter(account=current_account).first()
                if balance_obj:
                    live_balance = float(balance_obj.amount)
                    buying_power = live_balance
                
                # 2. Fetch Trades
                db_trades = Trade.objects.filter(account=current_account)
                
                for t in db_trades:
                    sort_dt = t.close_time if t.close_time else (t.open_time if t.open_time else timezone.now())
                    
                    all_processed_trades.append({
                        'trade_id': t.trade_id,
                        'symbol': t.symbol,
                        'direction': t.direction,
                        'lot_size': float(t.lot_size),
                        'profit': float(t.profit),
                        'open_price': float(t.open_price),
                        'close_price': float(t.close_price),
                        'sort_date': sort_dt,
                        'date_str': sort_dt.strftime("%Y-%m-%d"),
                        'source': 'Database'
                    })
            except Exception as e:
                print(f"Dashboard DB Error: {e}")

    # =========================================================
    # 3. COMMON PROCESSING
    # =========================================================
    
    all_processed_trades.sort(key=lambda x: x['sort_date'])

    total_wins = 0; total_losses = 0; gross_profit = 0.0; gross_loss = 0.0
    today_wins = 0; today_total = 0; running_equity = 0.0; peak_equity = 0.0
    
    today_str = str(timezone.now().date())

    for t in all_processed_trades:
        pnl = t['profit']
        
        # Stats Calculation
        if pnl > 0: 
            total_wins += 1
            gross_profit += pnl
        else: 
            total_losses += 1
            gross_loss += abs(pnl)
        
        # Daily Stats
        if t['date_str'] == today_str:
            today_total += 1
            if pnl > 0: today_wins += 1
        
        # Equity Curve
        running_equity += pnl
        if running_equity > peak_equity: peak_equity = running_equity
        dd = running_equity - peak_equity
        
        equity_curve.append({'date': t['date_str'], 'value': round(running_equity, 2)})
        drawdown_curve.append({'date': t['date_str'], 'value': round(dd, 2)})
        
        # Calendar Map
        d_str = t['date_str']
        if d_str not in daily_map: daily_map[d_str] = {'pnl': 0.0, 'count': 0}
        daily_map[d_str]['pnl'] += pnl
        daily_map[d_str]['count'] += 1

    # Final Stats Calculation
    total_count = total_wins + total_losses
    if total_count > 0: stats['win_rate'] = int((total_wins / total_count) * 100)
    if gross_loss > 0: stats['profit_factor'] = round(gross_profit / gross_loss, 2)
    elif gross_profit > 0: stats['profit_factor'] = 99.9 
    if today_total > 0: stats['day_win_rate'] = int((today_wins / today_total) * 100)

    # Sort reverse chronological (Newest -> Oldest) for the "Recent Trades" table
    all_processed_trades.sort(key=lambda x: x['sort_date'], reverse=True)
    positions = all_processed_trades[:5]

    # Calendar Grid Generation
    target_year = int(request.GET.get('year', timezone.now().year))
    target_month = int(request.GET.get('month', timezone.now().month))
    cal = calendar.Calendar(firstweekday=6)
    month_days_raw = list(cal.itermonthdays(target_year, target_month))
    
    for day_num in month_days_raw:
        if day_num == 0: monthly_days.append({'day': '', 'has_data': False})
        else:
            d_str = f"{target_year}-{target_month:02d}-{day_num:02d}"
            day_data = daily_map.get(d_str)
            if day_data: monthly_days.append({'day': day_num, 'has_data': True, 'pnl': day_data['pnl'], 'count': day_data['count']})
            else: monthly_days.append({'day': day_num, 'has_data': False, 'pnl': 0, 'count': 0})

    return render(request, 'dashboard.html', {
        'accounts': user_accounts, 
        'current_account': current_account, 
        'stats': stats, 
        'positions': positions, 
        'equity_curve': equity_curve, 
        'drawdown_curve': drawdown_curve, 
        'monthly_days': monthly_days, 
        'is_connected': is_connected, 
        'balance': live_balance, 
        'buying_power': buying_power, 
        'today_date': timezone.now(), 
        'target_year': target_year, 
        'target_month': target_month
    })

# --- 4. DAILY TRADES VIEW ---
@login_required
def daily_trades(request, year, month, day):
    current_account, user_accounts = get_active_account(request)
    target_date_str = f"{year}-{month:02d}-{day:02d}"
    day_trades = []
    
    # API FETCH
    if current_account and current_account.snaptrade_user_id:
        try:
            client = TradeSmartCloud()
            ST_UID = current_account.snaptrade_user_id
            ST_SECRET = current_account.user_secret
            cloud_accounts = client.get_accounts(ST_UID, ST_SECRET)
            if cloud_accounts:
                acc_id = cloud_accounts[0]['id']
                orders_res = client.api.account_information.get_user_account_orders(ST_UID, ST_SECRET, acc_id)
                all_orders = orders_res.body if isinstance(orders_res.body, list) else []
                
                chron_orders = sorted(all_orders, key=lambda x: x.get('time_executed') or x.get('time_placed') or '0000-00-00', reverse=False)
                inventory = {} 

                for order in chron_orders:
                    raw_date = (order.get('time_executed') or order.get('time_placed') or order.get('time_updated') or order.get('execution_time'))
                    trade_date_str = "0000-00-00"
                    final_time_str = "--:--:--"
                    
                    if raw_date:
                        try:
                            if str(raw_date).isdigit():
                                dt = datetime.fromtimestamp(int(raw_date) / 1000.0)
                                trade_date_str = str(dt.date())
                                final_time_str = dt.strftime("%H:%M:%S")
                            else:
                                trade_date_str = str(raw_date)[:10]
                                try: dt = datetime.fromisoformat(str(raw_date).replace('Z', '+00:00')); final_time_str = dt.strftime("%H:%M:%S")
                                except: final_time_str = str(raw_date)[11:19]
                        except: trade_date_str = str(raw_date)[:10]

                    sym_obj = order.get('universal_symbol') or order.get('symbol')
                    symbol = extract_clean_symbol(sym_obj)
                    action = order.get('action', '').upper()
                    units = float(order.get('filled_quantity') or order.get('total_quantity') or 0.0)
                    price = float(order.get('execution_price') or order.get('price') or 0.0)
                    trade_pnl = 0.0; trade_closed = False; closing_price = price; opening_price = 0.0

                    if symbol not in inventory: inventory[symbol] = {'qty': 0.0, 'avg_price': 0.0}
                    current_qty = inventory[symbol]['qty']; avg_entry = inventory[symbol]['avg_price']

                    if action == 'BUY':
                        if current_qty < 0:
                            opening_price = avg_entry; cover_qty = min(abs(current_qty), units)
                            trade_pnl = (avg_entry - price) * cover_qty; trade_closed = True
                            inventory[symbol]['qty'] += cover_qty
                            if inventory[symbol]['qty'] == 0: inventory[symbol]['avg_price'] = 0.0
                            remainder = units - cover_qty
                            if remainder > 0: inventory[symbol]['qty'] += remainder; inventory[symbol]['avg_price'] = price 
                        else:
                            total_val = (current_qty * avg_entry) + (units * price); new_total_qty = current_qty + units
                            if new_total_qty > 0: inventory[symbol]['avg_price'] = total_val / new_total_qty
                            inventory[symbol]['qty'] = new_total_qty
                    elif action == 'SELL':
                        if current_qty > 0:
                            opening_price = avg_entry; close_qty = min(current_qty, units)
                            trade_pnl = (price - avg_entry) * close_qty; trade_closed = True
                            inventory[symbol]['qty'] -= close_qty
                            if inventory[symbol]['qty'] == 0: inventory[symbol]['avg_price'] = 0.0
                            remainder = units - close_qty
                            if remainder > 0: inventory[symbol]['qty'] -= remainder; inventory[symbol]['avg_price'] = price 
                        else:
                            total_val = (abs(current_qty) * avg_entry) + (units * price); new_total_abs_qty = abs(current_qty) + units
                            if new_total_abs_qty > 0: inventory[symbol]['avg_price'] = total_val / new_total_abs_qty
                            inventory[symbol]['qty'] -= units

                    if trade_closed and trade_date_str == target_date_str:
                        tid = generate_trade_id(order)
                        day_trades.append({'trade_id': tid, 'ticket': tid, 'symbol': symbol, 'direction': action, 'type': action, 'volume': units, 'qty': units, 'lot_size': units, 'open_price': round(opening_price, 2), 'close_price': round(closing_price, 2), 'profit': round(trade_pnl, 2), 'time': final_time_str})

        except Exception as e:
            print(f"Daily Trades Error: {e}")
    
    # DB FETCH (MANUAL)
    else:
        db_trades = Trade.objects.filter(account=current_account)
        for t in db_trades:
            if t.symbol == 'BALANCE': continue # Skip balance ops in daily view
            
            # Use open time for daily grouping
            trade_date = t.open_time.date() if t.open_time else None
            if str(trade_date) == target_date_str:
                day_trades.append({
                    'trade_id': t.trade_id,
                    'ticket': t.trade_id,
                    'symbol': t.symbol,
                    'direction': t.direction,
                    'type': t.direction,
                    'volume': float(t.lot_size),
                    'qty': float(t.lot_size),
                    'lot_size': float(t.lot_size),
                    'open_price': float(t.open_price),
                    'close_price': float(t.close_price),
                    'profit': float(t.profit),
                    'time': t.open_time.strftime("%H:%M:%S") if t.open_time else "--:--:--"
                })

    day_trades.sort(key=lambda x: str(x.get('time')), reverse=True)
    return render(request, 'daily_trades.html', {'trades': day_trades, 'date_str': target_date_str, 'accounts': user_accounts, 'current_account': current_account})

# --- 5. JOURNAL ---
@login_required
def journal(request):
    current_account, user_accounts = get_active_account(request)
    journal_trades = []
    
    # Defaults
    stats = {
        'net_pnl': 0.00,
        'win_rate': 0,
        'profit_factor': 0.00,
        'total_trades': 0,
        'avg_win': 0.00,
        'avg_loss': 0.00
    }

    # =========================================================
    # SOURCE 1: LOCAL DATABASE (Imported Files)
    # =========================================================
    if current_account:
        try:
            # Fetch trades saved in the DB for this account
            db_trades = Trade.objects.filter(account=current_account).order_by('-open_time')
            
            for t in db_trades:
                if t.symbol == 'BALANCE': continue # Don't show deposits in Trade List

                # Convert Model Object to Dictionary to match API format
                journal_trades.append({
                    'trade_id': t.trade_id,
                    'id': t.trade_id,
                    'symbol': t.symbol,
                    'open_time': t.open_time,
                    'full_date': t.open_time.strftime("%Y-%m-%d") if t.open_time else "",
                    'date': t.open_time.strftime("%H:%M") if t.open_time else "",
                    'direction': t.direction,
                    'type': t.direction,
                    'lot_size': float(t.lot_size),
                    'lots': float(t.lot_size),
                    'open_price': float(t.open_price),
                    'entry': float(t.open_price),
                    'close_price': float(t.close_price),
                    'exit': float(t.close_price),
                    'profit': float(t.profit),
                    'pnl': float(t.profit),
                    'strategy': t.strategy_tag or 'Manual',
                    'source': 'Database'
                })
        except Exception as e:
            print(f"Journal DB Error: {e}")

    # =========================================================
    # SOURCE 2: SNAPTRADE API (Live Sync)
    # =========================================================
    if current_account and current_account.snaptrade_user_id:
        try:
            client = TradeSmartCloud(); ST_UID = current_account.snaptrade_user_id; ST_SECRET = current_account.user_secret
            cloud_accounts = client.get_accounts(ST_UID, ST_SECRET)
            if cloud_accounts:
                acc_id = cloud_accounts[0]['id']
                orders_res = client.api.account_information.get_user_account_orders(ST_UID, ST_SECRET, acc_id)
                all_orders = orders_res.body if isinstance(orders_res.body, list) else []
                
                # Sort for FIFO
                chron_orders = sorted(all_orders, key=lambda x: x.get('time_executed') or x.get('time_placed') or '0000-00-00', reverse=False)
                inventory = {} 

                for order in chron_orders:
                    # [DATE PARSING]
                    raw_date = (order.get('time_executed') or order.get('time_placed') or order.get('time_updated') or order.get('execution_time'))
                    trade_dt = timezone.now()
                    trade_date_str = "0000-00-00"; final_time_str = "--:--:--"
                    
                    if raw_date:
                        try:
                            if str(raw_date).isdigit(): 
                                dt = datetime.fromtimestamp(int(raw_date) / 1000.0)
                                trade_dt = make_aware(dt)
                                trade_date_str = str(dt.date())
                                final_time_str = dt.strftime("%H:%M:%S")
                            else: 
                                trade_date_str = str(raw_date)[:10]
                                trade_dt = datetime.fromisoformat(str(raw_date).replace('Z', '+00:00'))
                        except: 
                            trade_date_str = str(raw_date)[:10]

                    # [DATA EXTRACTION]
                    sym_obj = order.get('universal_symbol') or order.get('symbol'); symbol = extract_clean_symbol(sym_obj)
                    action = order.get('action', '').upper()
                    units = float(order.get('filled_quantity') or order.get('total_quantity') or 0.0)
                    price = float(order.get('execution_price') or order.get('price') or 0.0)
                    
                    trade_pnl = 0.0; trade_closed = False; closing_price = price; opening_price = 0.0

                    # [FIFO LOGIC]
                    if symbol not in inventory: inventory[symbol] = {'qty': 0.0, 'avg_price': 0.0}
                    current_qty = inventory[symbol]['qty']; avg_entry = inventory[symbol]['avg_price']

                    if action == 'BUY':
                        if current_qty < 0: # Closing Short
                            opening_price = avg_entry; cover_qty = min(abs(current_qty), units)
                            trade_pnl = (avg_entry - price) * cover_qty; trade_closed = True
                            inventory[symbol]['qty'] += cover_qty
                            if inventory[symbol]['qty'] == 0: inventory[symbol]['avg_price'] = 0.0
                            if units - cover_qty > 0: inventory[symbol]['qty'] += (units - cover_qty); inventory[symbol]['avg_price'] = price 
                        else: # Opening Long
                            total_val = (current_qty * avg_entry) + (units * price); new_total_qty = current_qty + units
                            if new_total_qty > 0: inventory[symbol]['avg_price'] = total_val / new_total_qty
                            inventory[symbol]['qty'] = new_total_qty
                    elif action == 'SELL':
                        if current_qty > 0: # Closing Long
                            opening_price = avg_entry; close_qty = min(current_qty, units)
                            trade_pnl = (price - avg_entry) * close_qty; trade_closed = True
                            inventory[symbol]['qty'] -= close_qty
                            if inventory[symbol]['qty'] == 0: inventory[symbol]['avg_price'] = 0.0
                            if units - close_qty > 0: inventory[symbol]['qty'] -= (units - close_qty); inventory[symbol]['avg_price'] = price 
                        else: # Opening Short
                            total_val = (abs(current_qty) * avg_entry) + (units * price); new_total_abs_qty = abs(current_qty) + units
                            if new_total_abs_qty > 0: inventory[symbol]['avg_price'] = total_val / new_total_abs_qty
                            inventory[symbol]['qty'] -= units

                    if trade_closed:
                        direction = 'LONG' if action == 'SELL' else 'SHORT'
                        tid = generate_trade_id(order)
                        
                        journal_trades.append({
                            'trade_id': tid,
                            'id': tid, 
                            'open_time': trade_dt, 
                            'date': final_time_str,
                            'full_date': trade_date_str,
                            'symbol': symbol, 
                            'type': direction,
                            'direction': direction,
                            'lots': units,
                            'lot_size': units,
                            'entry': round(opening_price, 2),
                            'open_price': round(opening_price, 2),
                            'exit': round(closing_price, 2),
                            'close_price': round(closing_price, 2),
                            'pnl': round(trade_pnl, 2),
                            'profit': round(trade_pnl, 2),
                            'strategy': 'Auto-Sync',
                            'source': 'API'
                        })
        except Exception as e: print(f"Journal API Error: {e}")

    # =========================================================
    # 3. FILTERS & SORTING
    # =========================================================
    
    # Sort by Open Time (Newest First)
    try:
        journal_trades.sort(key=lambda x: x.get('open_time') if x.get('open_time') else timezone.now(), reverse=True)
    except:
        pass 

    # Apply Filters from Request
    q = request.GET.get('q', '').strip().upper()
    side = request.GET.get('side', 'all').lower()
    outcome = request.GET.get('outcome', 'all').lower()
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    # Filter: Symbol (Search)
    if q:
        journal_trades = [t for t in journal_trades if q in t['symbol'].upper()]

    # Filter: Side
    if side != 'all':
        target_sides = ['buy', 'long'] if side in ['buy', 'long'] else ['sell', 'short']
        journal_trades = [t for t in journal_trades if str(t['type']).lower() in target_sides or str(t['direction']).lower() in target_sides]

    # Filter: Outcome (Win/Loss)
    if outcome != 'all':
        if outcome == 'win':
            journal_trades = [t for t in journal_trades if t['pnl'] > 0]
        elif outcome == 'loss':
            journal_trades = [t for t in journal_trades if t['pnl'] <= 0]

    # Filter: Date Range
    if start_date and end_date:
        journal_trades = [t for t in journal_trades if start_date <= t['full_date'] <= end_date]

    # =========================================================
    # 4. CALCULATE STATS (On Filtered Data)
    # =========================================================
    if journal_trades:
        total_pnl = sum(t['pnl'] for t in journal_trades)
        wins = [t['pnl'] for t in journal_trades if t['pnl'] > 0]
        losses = [abs(t['pnl']) for t in journal_trades if t['pnl'] <= 0]
        
        stats['net_pnl'] = round(total_pnl, 2)
        stats['total_trades'] = len(journal_trades)
        
        if stats['total_trades'] > 0:
            stats['win_rate'] = round((len(wins) / stats['total_trades']) * 100)
        
        gross_profit = sum(wins)
        gross_loss = sum(losses)
        
        if gross_loss > 0:
            stats['profit_factor'] = round(gross_profit / gross_loss, 2)
        elif gross_profit > 0:
            stats['profit_factor'] = 99.99
            
        if wins: stats['avg_win'] = round(sum(wins) / len(wins), 2)
        if losses: stats['avg_loss'] = round(sum(losses) / len(losses), 2)

    return render(request, 'journal.html', {
        'journal_trades': journal_trades, 
        'stats': stats, 
        'current_account': current_account, 
        'accounts': user_accounts
    })

# --- 6. LIVE MONITOR ---
@login_required
def live_monitor(request):
    current_account, user_accounts = get_active_account(request)
    
    if not current_account or not current_account.snaptrade_user_id:
        return render(request, 'live_monitor_locked.html', {
            'accounts': user_accounts, 
            'current_account': current_account
        })

    clean_trades = []; floating_pnl = 0.00
    is_connected = False
    
    is_ajax_poll = (request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.GET.get('action') == 'get_pnl')

    if request.method == 'POST':
        symbol = request.POST.get('symbol')
        qty = request.POST.get('qty') 
        note_content = request.POST.get('note')
        emotion = request.POST.get('emotion')
        
        if symbol and note_content:
            try:
                link_key = generate_linking_key(symbol, qty)
                unique_live_id = f"LIVE_NOTE_{request.user.id}_{link_key}"
                
                trade_obj, _ = Trade.objects.get_or_create(
                    user=request.user,
                    trade_id=unique_live_id,
                    defaults={
                        'account': current_account,
                        'symbol': symbol,
                        'lot_size': float(qty) if qty else 0.0,
                        'strategy_tag': "Live Monitor Log",
                        'source_platform': "Live Monitor",
                        'open_time': timezone.now()
                    }
                )
                
                TradeNote.objects.create(
                    trade=trade_obj, 
                    content=note_content, 
                    emotion_tag=emotion
                )
                return redirect('live_monitor')
            except Exception as e:
                print(f"Error saving live note: {e}")

    if current_account and current_account.snaptrade_user_id:
        try:
            client = TradeSmartCloud(); ST_UID = current_account.snaptrade_user_id; ST_SECRET = current_account.user_secret
            cloud_accounts = client.get_accounts(ST_UID, ST_SECRET)
            if cloud_accounts:
                is_connected = True; acc_id = cloud_accounts[0]['id']
                portfolio_data = client.fetch_positions(ST_UID, ST_SECRET, acc_id)
                raw_positions = portfolio_data.get('positions', []) if isinstance(portfolio_data, dict) else []
                
                for pos in raw_positions:
                    pnl = float(pos.get('open_pnl', 0) or 0.0); floating_pnl += pnl
                    if not is_ajax_poll:
                        raw_asset = pos.get('symbol')
                        asset_name = extract_clean_symbol(raw_asset)
                        qty = float(pos.get('units', 0) or 0.0)
                        price = float(pos.get('price', 0) or 0.0)
                        clean_trades.append({'name': asset_name, 'qty': qty, 'price': price, 'pnl': pnl})
        except: pass

    if is_ajax_poll: return JsonResponse({'status': 'success', 'pnl': round(floating_pnl, 2)})

    return render(request, 'live_monitor.html', {'open_trades': clean_trades, 'floating_pnl': round(floating_pnl, 2), 'has_active_account': is_connected, 'current_account': current_account, 'accounts': user_accounts})

# --- 7. PROFILE & MANAGEMENT ---
@login_required
def profile_view(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    accounts = TradingAccount.objects.filter(user=request.user)
    
    # --- ADDED THIS LINE ---
    # Required because your sidebar HTML checks "if current_account.snaptrade_user_id"
    current_account, _ = get_active_account(request) 
    
    context = {
        'profile': profile, 
        'accounts': accounts,
        'current_account': current_account # Passed to template
    }
    return render(request, 'profile.html', context)

@login_required
def delete_trading_account(request, account_id):
    # Ensure the account belongs to the logged-in user for security
    account = get_object_or_404(TradingAccount, id=account_id, user=request.user)
    
    if request.method == 'POST':
        broker_name = account.broker_name
        
        # 1. REMOTE CLEANUP (SnapTrade)
        # We do this BEFORE local deletion. If this runs, the "Connection Limit" is freed.
        if account.snaptrade_user_id:
            try:
                client = TradeSmartCloud()
                # Use the helper method (ensure delete_snaptrade_user is added to TradeSmartCloud class)
                success = client.delete_snaptrade_user(account.snaptrade_user_id)
                
                if not success:
                    # Non-blocking warning
                    messages.warning(request, "Account deleted locally, but SnapTrade cleanup failed. Check logs.")
            except Exception as e:
                print(f"SnapTrade Deletion Error: {e}")

        # 2. LOCAL CLEANUP (Database)
        account.delete()

        # 3. SESSION CLEANUP
        # Check if the deleted account was the one currently active in the session
        if str(request.session.get('active_account_id')) == str(account_id):
            if 'active_account_id' in request.session:
                del request.session['active_account_id']

        messages.success(request, f"Successfully disconnected {broker_name}.")
        return redirect('settings') # Redirect back to Profile/Settings page

    # Optional confirmation render, though usually handled via modal/confirm() in settings
    return render(request, 'confirm_delete.html', {'account': account})
# --- 8. TRADE DETAIL (WITH SMART LINKING) ---
@login_required
def trade_detail(request, trade_id):
    current_account, user_accounts = get_active_account(request)
    target_trade = None

    if current_account and current_account.snaptrade_user_id:
        try:
            client = TradeSmartCloud(); ST_UID = current_account.snaptrade_user_id; ST_SECRET = current_account.user_secret
            cloud_accounts = client.get_accounts(ST_UID, ST_SECRET)
            if cloud_accounts:
                acc_id = cloud_accounts[0]['id']
                orders_res = client.api.account_information.get_user_account_orders(ST_UID, ST_SECRET, acc_id)
                all_orders = orders_res.body if isinstance(orders_res.body, list) else []
                
                chron_orders = sorted(all_orders, key=lambda x: x.get('time_executed') or x.get('time_placed') or '0000-00-00', reverse=False)
                inventory = {} 

                for order in chron_orders:
                    # 1. Parse Date
                    raw_date = (order.get('time_executed') or order.get('time_placed') or order.get('time_updated') or order.get('execution_time'))
                    final_time_str = "--:--"
                    close_dt = timezone.now() # Default
                    
                    if raw_date:
                        try:
                            if str(raw_date).isdigit(): 
                                dt = datetime.fromtimestamp(int(raw_date) / 1000.0)
                                close_dt = make_aware(dt) # Aware datetime for comparison
                                final_time_str = dt.strftime("%Y-%m-%d %H:%M:%S")
                            else: 
                                final_time_str = str(raw_date)[:19]
                                try: close_dt = datetime.fromisoformat(str(raw_date).replace('Z', '+00:00'))
                                except: pass
                        except: final_time_str = str(raw_date)

                    sym_obj = order.get('universal_symbol') or order.get('symbol')
                    symbol = extract_clean_symbol(sym_obj)
                    action = order.get('action', '').upper()
                    units = float(order.get('filled_quantity') or 0.0)
                    price = float(order.get('execution_price') or 0.0)
                    
                    trade_pnl = 0.0; trade_closed = False; closing_price = price; opening_price = 0.0

                    # 3. FIFO Logic
                    if symbol not in inventory: inventory[symbol] = {'qty': 0.0, 'avg_price': 0.0}
                    current_qty = inventory[symbol]['qty']; avg_entry = inventory[symbol]['avg_price']

                    if action == 'BUY':
                        if current_qty < 0:
                            opening_price = avg_entry; cover_qty = min(abs(current_qty), units); trade_pnl = (avg_entry - price) * cover_qty; trade_closed = True; inventory[symbol]['qty'] += cover_qty
                            if inventory[symbol]['qty'] == 0: inventory[symbol]['avg_price'] = 0.0
                            if units - cover_qty > 0: inventory[symbol]['qty'] += (units - cover_qty); inventory[symbol]['avg_price'] = price 
                        else:
                            total_val = (current_qty * avg_entry) + (units * price); new_qty = current_qty + units
                            if new_qty > 0: inventory[symbol]['avg_price'] = total_val / new_qty
                            inventory[symbol]['qty'] = new_qty
                    elif action == 'SELL':
                        if current_qty > 0:
                            opening_price = avg_entry; close_qty = min(current_qty, units); trade_pnl = (price - avg_entry) * close_qty; trade_closed = True; inventory[symbol]['qty'] -= close_qty
                            if inventory[symbol]['qty'] == 0: inventory[symbol]['avg_price'] = 0.0
                            if units - close_qty > 0: inventory[symbol]['qty'] -= (units - close_qty); inventory[symbol]['avg_price'] = price 
                        else:
                            total_val = (abs(current_qty) * avg_entry) + (units * price); new_qty = abs(current_qty) + units
                            if new_qty > 0: inventory[symbol]['avg_price'] = total_val / new_qty
                            inventory[symbol]['qty'] -= units

                    # 4. SYNTHETIC ID MATCH
                    current_id = generate_trade_id(order)
                    
                    if trade_closed and current_id == trade_id:
                        direction = 'LONG' if action == 'SELL' else 'SHORT'
                        
                        target_trade = {
                            'id': trade_id,
                            'ticket': trade_id,
                            'symbol': symbol,
                            'type': direction,
                            'profit': round(trade_pnl, 2),
                            'entry_price': round(opening_price, 2),
                            'exit_price': round(closing_price, 2),
                            'lot_size': units,
                            'close_time': final_time_str,
                            'commission': 0.00,
                            'swap': 0.00
                        }
                        
                        # --- POST REQUEST HANDLER (SAVE NEW NOTE) ---
                        if request.method == 'POST' and 'note' in request.POST:
                            content = request.POST.get('note')
                            if content.strip():
                                try:
                                    local_trade, created = Trade.objects.get_or_create(
                                        trade_id=trade_id,
                                        defaults={
                                            'user': request.user,
                                            'account': current_account,
                                            'symbol': symbol,
                                            'direction': direction,
                                            'open_price': opening_price,
                                            'close_price': closing_price,
                                            'profit': trade_pnl,
                                            'lot_size': units,
                                            'open_time': timezone.now(),
                                            'close_time': timezone.now()
                                        }
                                    )
                                    TradeNote.objects.create(trade=local_trade, content=content)
                                    return redirect('trade_detail', trade_id=trade_id)
                                except Exception as e:
                                    print(f"Note Save Error: {e}")

                        # --- SMART LINKING: FIND NOTES BY UNIQUE KEY ---
                        link_key = generate_linking_key(symbol, units) 
                        unique_live_id = f"LIVE_NOTE_{request.user.id}_{link_key}"
                        
                        live_placeholder = Trade.objects.filter(trade_id=unique_live_id).first()
                        direct_notes = TradeNote.objects.filter(trade__trade_id=trade_id)
                        
                        if live_placeholder:
                            live_notes = TradeNote.objects.filter(trade=live_placeholder)
                            start_window = close_dt - timedelta(hours=48)
                            valid_live_notes = live_notes.filter(created_at__gte=start_window, created_at__lte=close_dt)
                            target_trade['notes'] = (direct_notes | valid_live_notes).order_by('-created_at')
                        else:
                            target_trade['notes'] = direct_notes.order_by('-created_at')
                            
                        break 
        except: pass

    # --- DB FALLBACK FOR MANUAL ACCOUNTS ---
    if not target_trade:
        # Check DB
        t = Trade.objects.filter(trade_id=trade_id).first()
        if t:
            target_trade = {
                'id': t.trade_id,
                'ticket': t.trade_id,
                'symbol': t.symbol,
                'type': t.direction,
                'profit': float(t.profit),
                'entry_price': float(t.open_price),
                'exit_price': float(t.close_price),
                'lot_size': float(t.lot_size),
                'close_time': t.close_time.strftime("%Y-%m-%d %H:%M") if t.close_time else "--:--",
                'commission': 0.00,
                'swap': 0.00,
                'notes': t.notes.all().order_by('-created_at')
            }
            # Note saving for manual trades
            if request.method == 'POST' and 'note' in request.POST:
                content = request.POST.get('note')
                if content.strip():
                    TradeNote.objects.create(trade=t, content=content)
                    return redirect('trade_detail', trade_id=trade_id)

    if not target_trade:
        target_trade = {'symbol': 'Not Found', 'profit': 0.0, 'entry_price': 0.0, 'exit_price': 0.0, 'type': '-', 'ticket': trade_id, 'notes': []}

    return render(request, 'trade_detail.html', {'trade': target_trade, 'current_account': current_account, 'accounts': user_accounts})

@login_required
def add_account(request):
    if request.method == 'POST':
        action_type = request.POST.get('action_type') # 'api' or 'manual'
        custom_name = request.POST.get('nickname', 'My Broker Account')
        
        # --- OPTION A: MANUAL ACCOUNT ---
        if action_type == 'manual':
            account = TradingAccount.objects.create(
                user=request.user, 
                broker_name=custom_name,
                snaptrade_user_id=None, 
                user_secret=None
            )
            request.session['active_account_id'] = account.id
            return redirect('import_trades')

        # --- OPTION B: API ACCOUNT (SNAPTRADE) ---
        else:
            client = TradeSmartCloud()
            new_st_id = f"TradeSmart_User_{request.user.id}_{str(uuid.uuid4())[:8]}"
            
            user_id, user_secret = client.register_user(new_st_id)
            
            if user_id and user_secret:
                account = TradingAccount.objects.create(
                    user=request.user, 
                    broker_name=custom_name, 
                    snaptrade_user_id=user_id, 
                    user_secret=user_secret
                )
                request.session['active_account_id'] = account.id
                
                # --- FIX FOR PYLANCE IS HERE ---
                # 1. Define the base URL first
                base_url = request.build_absolute_uri(reverse('dashboard'))
                
                # 2. Add the query parameter
                dashboard_url = f"{base_url}?connected=true"
                
                # 3. Generate the link
                login_link = client.generate_login_link(
                    user_id=user_id, 
                    user_secret=user_secret, 
                    redirect_uri=dashboard_url
                )
                
                return redirect(login_link)

    return render(request, 'add_account.html')
@login_required
def settings_view(request):
    # 1. Get Profile
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    
    # 2. Handle Profile Form Submission (Risk Appetite, etc.)
    if request.method == 'POST':
        form = ProfileUpdateForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile settings updated.")
            return redirect('settings')
    else:
        form = ProfileUpdateForm(instance=profile)

    # 3. Get Account Data
    # We explicitly filter accounts so the "Connected Accounts" list is accurate
    accounts = TradingAccount.objects.filter(user=request.user)
    
    # We get current_account so the Sidebar "Live Monitor" link works
    current_account, _ = get_active_account(request)

    context = {
        'form': form,
        'accounts': accounts,
        'current_account': current_account, 
        'profile': profile,
    }
    return render(request, 'settings.html', context)

@login_required
def lot_calculator(request):
    current_account, _ = get_active_account(request)
    context = {
        'current_account': current_account, 
    }
    return render(request, 'calculator.html', context)

@login_required
def generate_pdf_report(request, report_type):
    response = HttpResponse(content_type='application/pdf')
    p = canvas.Canvas(response)
    p.drawString(100, 800, "Report")
    p.save()
    return response

@login_required
def import_trades(request):
    current_account, user_accounts = get_active_account(request)
    if not current_account: return redirect('add_account')

    if request.method == 'POST':
        form = TradeImportForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = request.FILES['file']
            try:
                # --- 1. LOAD DATA ROBUSTLY ---
                uploaded_file.seek(0)
                try:
                    df_raw = pd.read_excel(uploaded_file, header=None, engine='openpyxl')
                except:
                    uploaded_file.seek(0)
                    try:
                        df_raw = pd.read_csv(uploaded_file, header=None, encoding='utf-8-sig')
                    except:
                        uploaded_file.seek(0)
                        try:
                            df_raw = pd.read_csv(uploaded_file, header=None) 
                        except:
                            uploaded_file.seek(0)
                            df_raw = pd.read_csv(uploaded_file, header=None, encoding='utf-16', sep='\t')

                if df_raw is None:
                    messages.error(request, "Could not read file. Check format.")
                    return redirect('journal')

                # =========================================================
                # PASS 1: EXTRACT BALANCE
                # =========================================================
                
                for idx, row in df_raw.iterrows():
                    col0 = str(row.iloc[0]).lower().strip()
                    if col0.startswith('balance') and 'drawdown' not in col0:
                        row_full_str = " ".join([str(x) for x in row.values])
                        clean_str = row_full_str.replace(',', '').replace(' ', '')
                        numbers = re.findall(r"[\d\.]+", clean_str)
                        
                        valid_balances = []
                        for n in numbers:
                            try:
                                val = float(n)
                                if val > 0: valid_balances.append(val)
                            except: continue
                        
                        if valid_balances:
                            final_balance = max(valid_balances)
                            AccountBalance.objects.update_or_create(
                                account=current_account,
                                defaults={'amount': final_balance}
                            )
                            break 

                # =========================================================
                # PASS 2: EXTRACT POSITIONS (BATCH PROCESSING)
                # =========================================================
                
                header_row_idx = None
                for idx, row in df_raw.iterrows():
                    row_str = " ".join([str(x).lower() for x in row.values])
                    if 'time' in row_str and 'symbol' in row_str and 'profit' in row_str:
                        header_row_idx = idx
                        break
                
                if header_row_idx is None:
                    messages.error(request, "Positions header not found.")
                    return redirect('journal')

                df_trades = df_raw.iloc[header_row_idx+1:].copy()
                
                raw_cols_dirty = df_raw.iloc[header_row_idx].astype(str).tolist()
                raw_cols = [re.sub(r'[^\w\s]', '', col).strip().lower() for col in raw_cols_dirty]

                deduped_cols = []
                col_counts = {}
                for col in raw_cols:
                    if col in col_counts:
                        col_counts[col] += 1
                        deduped_cols.append(f"{col}.{col_counts[col]}")
                    else:
                        col_counts[col] = 0
                        deduped_cols.append(col)
                df_trades.columns = deduped_cols
                
                def safe_float(val):
                    try: return float(str(val).replace(',', '').replace(' ', ''))
                    except: return 0.0

                # --- STEP A: PARSE FILE INTO MEMORY ---
                parsed_trades = [] # Stores dicts of trades from file

                for index, row in df_trades.iterrows():
                    col0 = str(row.iloc[0]).lower().strip()
                    if col0 in ['orders', 'deals', 'orders:', 'deals:']: break

                    raw_type = str(row.get('type') or row.get('direction') or '').lower().strip()
                    if raw_type not in ['buy', 'sell']: continue

                    raw_close_time = row.get('time.1') or row.get('close time')
                    if pd.isna(raw_close_time) or str(raw_close_time).strip() in ['', '0', 'nan', 'nat']: continue

                    pnl_raw = row.get('profit')
                    if pd.isna(pnl_raw) or str(pnl_raw).strip() == '': continue

                    symbol = row.get('symbol')
                    lots = safe_float(row.get('volume'))
                    entry = safe_float(row.get('price'))
                    exit_price = safe_float(row.get('price.1')) 
                    pnl = safe_float(pnl_raw)

                    try: open_time = pd.to_datetime(row.get('time') or row.get('open time'))
                    except: open_time = timezone.now()
                    try: close_time = pd.to_datetime(raw_close_time)
                    except: close_time = timezone.now()

                    unique_id = hashlib.md5(f"{current_account.id}-{open_time}-{symbol}-{pnl}-{lots}".encode()).hexdigest()

                    # Store for batch processing
                    parsed_trades.append({
                        'trade_id': unique_id,
                        'data': {
                            'user': request.user,
                            'account': current_account,
                            'symbol': symbol,
                            'direction': raw_type.upper(),
                            'lot_size': lots,
                            'open_price': entry,
                            'close_price': exit_price,
                            'profit': pnl,
                            'open_time': open_time,
                            'close_time': close_time,
                            'source_platform': 'Manual Import',
                            'status': 'CLOSED'
                        }
                    })

                if not parsed_trades:
                    messages.warning(request, "No closed trades found in file.")
                    return redirect('journal')

                # --- STEP B: CHECK FOR OVERLAP ---
                file_ids = [t['trade_id'] for t in parsed_trades]
                
                # Check if ANY of the file's trade IDs already exist in DB for this account
                existing_ids_in_db = set(
                    Trade.objects.filter(account=current_account, trade_id__in=file_ids)
                    .values_list('trade_id', flat=True)
                )

                trades_to_create = []

                if existing_ids_in_db:
                    # SCENARIO A: OVERLAP FOUND (Smart Append)
                    # Strategy: Ignore matches, insert only new ones.
                    for t in parsed_trades:
                        if t['trade_id'] not in existing_ids_in_db:
                            trades_to_create.append(Trade(trade_id=t['trade_id'], **t['data']))
                    
                    action_msg = f"Found overlapping history. Added {len(trades_to_create)} new trades."
                else:
                    # SCENARIO B: NO OVERLAP (Wipe & Replace)
                    # Strategy: Assuming new file or full re-import. Wipe existing, add all.
                    Trade.objects.filter(account=current_account).delete()
                    
                    for t in parsed_trades:
                        trades_to_create.append(Trade(trade_id=t['trade_id'], **t['data']))
                    
                    action_msg = f"Full import. Replaced history with {len(trades_to_create)} trades."

                # --- STEP C: BULK CREATE ---
                if trades_to_create:
                    Trade.objects.bulk_create(trades_to_create)

                bal_obj = AccountBalance.objects.filter(account=current_account).first()
                bal_msg = f" Balance: ${bal_obj.amount:,.2f}." if bal_obj else ""
                
                messages.success(request, f"{action_msg}{bal_msg}")
                return redirect('journal')

            except Exception as e:
                messages.error(request, f"Error processing file: {e}")
                
    else:
        form = TradeImportForm()

    return render(request, 'import_trades.html', {'form': form, 'current_account': current_account})