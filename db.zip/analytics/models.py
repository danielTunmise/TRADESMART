from django.db import models
from django.contrib.auth.models import User

# --- 1. TRADING ACCOUNT ---
class TradingAccount(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    
    # API Credentials
    snaptrade_user_id = models.CharField(max_length=100, unique=True, null=True, blank=True)
    user_secret = models.CharField(max_length=200, null=True, blank=True)
    
    broker_name = models.CharField(max_length=100, default="Unknown Broker")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.broker_name}"

# --- NEW TABLE: ACCOUNT BALANCE ---
class AccountBalance(models.Model):
    account = models.OneToOneField(TradingAccount, on_delete=models.CASCADE, related_name='balance')
    amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.account.broker_name}: ${self.amount}"

# --- 2. USER PROFILE ---
class UserProfile(models.Model):
    RISK_CHOICES = [
        ('conservative', 'Conservative (0.5-1%)'),
        ('moderate', 'Moderate (1-2%)'),
        ('aggressive', 'Aggressive (>2%)'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    risk_appetite = models.CharField(max_length=20, choices=RISK_CHOICES, default='moderate')
    daily_loss_limit = models.DecimalField(max_digits=10, decimal_places=2, default=500.00)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)

    def __str__(self):
        return f"{self.user.username} - {self.risk_appetite}"

# --- 3. TRADE ---
class Trade(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    account = models.ForeignKey('TradingAccount', on_delete=models.CASCADE, related_name='trades', null=True)
    
    trade_id = models.CharField(max_length=100, unique=True, null=True, blank=True) 
    symbol = models.CharField(max_length=20, null=True, blank=True)
    direction = models.CharField(max_length=10, null=True, blank=True)
    
    lot_size = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    profit = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    
    open_price = models.DecimalField(max_digits=12, decimal_places=5, default=0.00000)
    close_price = models.DecimalField(max_digits=12, decimal_places=5, default=0.00000)
    
    strategy_tag = models.CharField(max_length=50, blank=True, null=True)
    source_platform = models.CharField(max_length=50, default="Cloud-Sync") 
    status = models.CharField(max_length=20, default='CLOSED') 

    open_time = models.DateTimeField(null=True, blank=True)
    close_time = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.symbol} | {self.profit}"

# --- 4. TRADE NOTE ---
class TradeNote(models.Model):
    trade = models.ForeignKey(Trade, on_delete=models.CASCADE, related_name='notes')
    content = models.TextField()
    screenshot = models.ImageField(upload_to='trade_screenshots/', blank=True, null=True)
    sentiment_score = models.FloatField(default=0.0) 
    emotion_tag = models.CharField(max_length=50, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True) 

    def __str__(self):
        return f"Note for {self.trade.trade_id}"