import os
from snaptrade_client import SnapTrade
from django.conf import settings

class TradeSmartCloud:
    def __init__(self):
        # ---------------------------------------------------
        # YOUR API KEYS (Preserved from your code)
        # ---------------------------------------------------
        self.client_id = os.getenv("SNAPTRADE_CLIENT_ID", "TRADESMART-TEST-APNRW")
        self.consumer_key = os.getenv("SNAPTRADE_CONSUMER_KEY", "VkvPq2XCJxbKoEiGZSX31WzUpEvnCEfLjux7YwLi5dFmCG3MQE")
        # ---------------------------------------------------
        
        # Initialize the connection
        try:
            self.api = SnapTrade(
                client_id=self.client_id, 
                consumer_key=self.consumer_key
            )
        except Exception as e:
            print(f"⚠️ API Init Error: {e}")

    def test_connection(self):
        """
        Check if we can reach the API.
        """
        try:
            status = self.api.api_status.check()
            if status:
                print(f"✅ Connection Successful!")
                return True
        except Exception as e:
            print(f"❌ Connection Failed: {e}")
            return False
        
    def register_user(self, username):
        """
        Registers a new user on SnapTrade.
        """
        try:
            # We use the username as a reference ID
            user_data = self.api.authentication.register_snap_trade_user(
                user_id=username
            )
            print(f"✅ Registered {username} on SnapTrade!")
            return user_data.body['userId'], user_data.body['userSecret']
        except Exception as e:
            print(f"❌ Registration Failed: {e}")
            return None, None

    def generate_login_link(self, user_id, user_secret, redirect_uri=None):
        """
        Generates the secure link where the user logs into their broker.
        """
        try:
            # 1. Prepare arguments
            # We must tell SnapTrade explicitly to use a custom redirect
            kwargs = {
                "user_id": user_id,
                "user_secret": user_secret
            }
            
            if redirect_uri:
                print(f"🔗 Embedding redirect: {redirect_uri}")
                # These are the specific parameters SnapTrade expects
                kwargs["immediate_redirect"] = True
                kwargs["custom_redirect"] = redirect_uri

            # 2. Call the API with the redirect parameters
            response = self.api.authentication.login_snap_trade_user(**kwargs)
            
            # 3. Extract the link
            data = response.body
            
            # Handle different SDK return formats (dict vs object)
            if isinstance(data, dict):
                return data.get('redirectURI') or data.get('loginRedirectURI')
            
            return getattr(data, 'redirectURI', getattr(data, 'loginRedirectURI', None))
            
        except Exception as e:
            print(f"❌ Failed to generate link: {e}")
            return None

    def get_supported_brokers(self):
        """
        Returns a list of brokers we can connect to.
        """
        try:
            response = self.api.reference_data.list_all_brokerages()
            brokers = response.body
            return brokers
        except Exception as e:
            print(f"❌ Failed to fetch brokers: {e}")
            return []


    def get_accounts(self, user_id, user_secret):
        """
        Fetches all brokerage accounts linked by this user.
        """
        try:
            accounts = self.api.account_information.list_user_accounts(
                user_id=user_id,
                user_secret=user_secret
            )
            return accounts.body
        except Exception as e:
            print(f"❌ Failed to get accounts: {e}")
            return []

    def fetch_positions(self, user_id, user_secret, account_id):
        """
        Fetches currently open positions (Live Monitor).
        """
        try:
            holdings = self.api.account_information.get_user_holdings(
                user_id=user_id,
                user_secret=user_secret,
                account_id=account_id
            )
            return holdings.body
        except Exception as e:
            print(f"❌ Failed to fetch positions: {e}")
            return []
        
    def fetch_history(self, user_id, user_secret, account_id):
        """ Fetches recent account activities (orders, transfers). """
        try:
            # SnapTrade 'activities' endpoint returns all history
            activities = self.api.account_information.list_user_activities(
                user_id=user_id,
                user_secret=user_secret,
                account_id=account_id
            )
            return activities.body
        except Exception as e:
            print(f"❌ Failed to fetch history: {e}")
            return []
    # In utils.py inside TradeSmartCloud class

    def delete_snaptrade_user(self, user_id):
        """
        Permanently deletes the user from SnapTrade using the SDK.
        Includes proper signature handling to avoid 403 Forbidden errors.
        """
        try:
            print(f"🔥 Attempting to delete SnapTrade User: {user_id}")
            
            # USE THE SDK, NOT RAW REQUESTS
            self.api.authentication.delete_snap_trade_user(user_id=user_id)
            
            print(f"✅ Successfully deleted {user_id} from SnapTrade.")
            return True
            
        except Exception as e:
            # Check if error is actually "User not found" (which means success)
            if "404" in str(e) or "not found" in str(e).lower():
                print(f"⚠️ User {user_id} was already deleted.")
                return True
                
            print(f"❌ Error deleting SnapTrade user: {e}")
            return False