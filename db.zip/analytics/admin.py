from django.contrib import admin
from .models import UserProfile, Trade, TradeNote, AccountBalance 

# This tells the Admin Panel: "Show me these tables!"
admin.site.register(UserProfile)
admin.site.register(Trade)
admin.site.register(TradeNote)
admin.site.register(AccountBalance)  # <--- Add this line