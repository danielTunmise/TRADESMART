from textblob import TextBlob
from django.utils import timezone
from .models import Trade, TradingAccount
import numpy as np
# from sklearn.cluster import KMeans

# --- 0. HELPER: GET ACTIVE ACCOUNT ---
def get_active_account(request):
    """
    Retrieves the currently active TradingAccount based on session.
    If none selected, defaults to the first available account.
    Returns: (current_account, all_user_accounts)
    """
    user_accounts = TradingAccount.objects.filter(user=request.user)
    
    # 1. Try to get ID from session
    active_id = request.session.get('active_account_id')
    
    current_account = None
    
    if active_id:
        # Check if this ID actually belongs to the user
        current_account = user_accounts.filter(id=active_id).first()
    
    # 2. Fallback: If session ID is invalid or missing, pick the first account
    if not current_account and user_accounts.exists():
        current_account = user_accounts.first()
        # Update session to match
        request.session['active_account_id'] = current_account.id
        
    return current_account, user_accounts



