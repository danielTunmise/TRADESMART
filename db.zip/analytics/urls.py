from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    # --- Authentication ---
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    
    # NEW: Logout Route (Redirects to Login page)
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),

    path('', views.login_view, name='home'),
    
    # --- Main App Views ---
    path('dashboard/', views.dashboard, name='dashboard'),
    path('journal/', views.journal, name='journal'),
    
    # NEW: Manual Import Route
    path('import-trades/', views.import_trades, name='import_trades'),

    path('live-monitor/', views.live_monitor, name='live_monitor'),
    path('calculator/', views.lot_calculator, name='lot_calculator'),
    path('settings/', views.settings_view, name='settings'),
    path('profile/', views.profile_view, name='profile'),
    
    # --- Account Management ---
    path('add-account/', views.add_account, name='add_account'),
    path('delete-account/<int:account_id>/', views.delete_trading_account, name='delete_account'),
    path('sync-trades/', views.sync_trading_data, name='sync_trades'),
    path('account/delete/<int:account_id>/', views.delete_trading_account, name='delete_account'),
    
    # --- Reports & Details ---
    path('report/<str:report_type>/', views.generate_pdf_report, name='generate_report'),
    path('trade/<str:trade_id>/', views.trade_detail, name='trade_detail'),
    path('daily-trades/<int:year>/<int:month>/<int:day>/', views.daily_trades, name='daily_trades'),
    
    # --- Password Reset ---
    path('password-reset/', auth_views.PasswordResetView.as_view(template_name='password_reset_form.html'), name='password_reset'),
    path('password-reset-confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='password_reset_confirm.html'), name='password_reset_confirm'),
    path('password-reset/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('password-reset-complete/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
]